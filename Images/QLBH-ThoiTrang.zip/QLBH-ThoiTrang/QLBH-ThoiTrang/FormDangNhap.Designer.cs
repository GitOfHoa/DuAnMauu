﻿
namespace QLBH_ThoiTrang
{
    partial class FormDangNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDangNhap));
            this.panelDoiMatKhau = new System.Windows.Forms.Panel();
            this.pbOngVang = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtMatKhau = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnQuenMatKhau = new System.Windows.Forms.Label();
            this.chkghinhotk = new System.Windows.Forms.CheckBox();
            this.btnDong = new System.Windows.Forms.Button();
            this.btnDangNhap = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panelDoiMatKhau.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbOngVang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelDoiMatKhau
            // 
            this.panelDoiMatKhau.BackColor = System.Drawing.Color.Transparent;
            this.panelDoiMatKhau.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelDoiMatKhau.BackgroundImage")));
            this.panelDoiMatKhau.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelDoiMatKhau.Controls.Add(this.pbOngVang);
            this.panelDoiMatKhau.Controls.Add(this.pictureBox1);
            this.panelDoiMatKhau.Controls.Add(this.txtMatKhau);
            this.panelDoiMatKhau.Controls.Add(this.txtEmail);
            this.panelDoiMatKhau.Controls.Add(this.label3);
            this.panelDoiMatKhau.Controls.Add(this.label2);
            this.panelDoiMatKhau.Controls.Add(this.btnQuenMatKhau);
            this.panelDoiMatKhau.Controls.Add(this.chkghinhotk);
            this.panelDoiMatKhau.Controls.Add(this.btnDong);
            this.panelDoiMatKhau.Controls.Add(this.btnDangNhap);
            this.panelDoiMatKhau.Location = new System.Drawing.Point(228, 124);
            this.panelDoiMatKhau.Name = "panelDoiMatKhau";
            this.panelDoiMatKhau.Size = new System.Drawing.Size(751, 484);
            this.panelDoiMatKhau.TabIndex = 1;
            // 
            // pbOngVang
            // 
            this.pbOngVang.Image = ((System.Drawing.Image)(resources.GetObject("pbOngVang.Image")));
            this.pbOngVang.Location = new System.Drawing.Point(43, 72);
            this.pbOngVang.Name = "pbOngVang";
            this.pbOngVang.Size = new System.Drawing.Size(246, 342);
            this.pbOngVang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbOngVang.TabIndex = 34;
            this.pbOngVang.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QLBH_ThoiTrang.Properties.Resources.z2903598913015_148bd21607fe5eeccb02432c1c090ff3;
            this.pictureBox1.Location = new System.Drawing.Point(411, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(168, 105);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // txtMatKhau
            // 
            this.txtMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatKhau.Location = new System.Drawing.Point(313, 260);
            this.txtMatKhau.Name = "txtMatKhau";
            this.txtMatKhau.Size = new System.Drawing.Size(329, 32);
            this.txtMatKhau.TabIndex = 32;
            this.txtMatKhau.UseSystemPasswordChar = true;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(313, 177);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(330, 32);
            this.txtEmail.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(308, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 26);
            this.label3.TabIndex = 30;
            this.label3.Text = "Mật Khẩu:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(308, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 26);
            this.label2.TabIndex = 29;
            this.label2.Text = "Email:";
            // 
            // btnQuenMatKhau
            // 
            this.btnQuenMatKhau.AutoSize = true;
            this.btnQuenMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuenMatKhau.ForeColor = System.Drawing.Color.Blue;
            this.btnQuenMatKhau.Location = new System.Drawing.Point(506, 303);
            this.btnQuenMatKhau.Name = "btnQuenMatKhau";
            this.btnQuenMatKhau.Size = new System.Drawing.Size(157, 24);
            this.btnQuenMatKhau.TabIndex = 28;
            this.btnQuenMatKhau.Text = "Quên Mật Khẩu ?";
            this.btnQuenMatKhau.Click += new System.EventHandler(this.btnQuenMatKhau_Click);
            // 
            // chkghinhotk
            // 
            this.chkghinhotk.AutoSize = true;
            this.chkghinhotk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkghinhotk.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chkghinhotk.Location = new System.Drawing.Point(313, 304);
            this.chkghinhotk.Name = "chkghinhotk";
            this.chkghinhotk.Size = new System.Drawing.Size(172, 24);
            this.chkghinhotk.TabIndex = 27;
            this.chkghinhotk.Text = "Ghi Nhớ Tài Khoản";
            this.chkghinhotk.UseVisualStyleBackColor = true;
            this.chkghinhotk.CheckedChanged += new System.EventHandler(this.chkghinhotk_CheckedChanged);
            // 
            // btnDong
            // 
            this.btnDong.BackColor = System.Drawing.Color.Tomato;
            this.btnDong.FlatAppearance.BorderSize = 0;
            this.btnDong.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDong.Location = new System.Drawing.Point(510, 352);
            this.btnDong.Name = "btnDong";
            this.btnDong.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnDong.Size = new System.Drawing.Size(165, 45);
            this.btnDong.TabIndex = 26;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = false;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // btnDangNhap
            // 
            this.btnDangNhap.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnDangNhap.FlatAppearance.BorderSize = 0;
            this.btnDangNhap.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangNhap.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDangNhap.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDangNhap.Location = new System.Drawing.Point(313, 352);
            this.btnDangNhap.Name = "btnDangNhap";
            this.btnDangNhap.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnDangNhap.Size = new System.Drawing.Size(165, 45);
            this.btnDangNhap.TabIndex = 25;
            this.btnDangNhap.Text = "Đăng Nhập";
            this.btnDangNhap.UseVisualStyleBackColor = false;
            this.btnDangNhap.Click += new System.EventHandler(this.btnDangNhap_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(495, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(230, 44);
            this.label6.TabIndex = 25;
            this.label6.Text = "Đăng Nhập ";
            // 
            // FormDangNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 772);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panelDoiMatKhau);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormDangNhap";
            this.Text = "FormDangNhap";
            this.Load += new System.EventHandler(this.FormDangNhap_Load);
            this.panelDoiMatKhau.ResumeLayout(false);
            this.panelDoiMatKhau.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbOngVang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelDoiMatKhau;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label btnQuenMatKhau;
        private System.Windows.Forms.CheckBox chkghinhotk;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.Button btnDangNhap;
        private System.Windows.Forms.TextBox txtMatKhau;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbOngVang;
    }
}